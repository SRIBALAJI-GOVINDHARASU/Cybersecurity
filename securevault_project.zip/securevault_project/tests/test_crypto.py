import os
import shutil
import subprocess
import sys
import tempfile
import unittest

from securevault import crypto
from securevault.crypto import DecryptionError, FormatError, HEADER_LEN
from securevault.passwords import estimate_strength, generate_password
from securevault.shred import secure_delete

def rd(path):
    with open(path, "rb") as f:
        return f.read()


def wr(path, data):
    with open(path, "wb") as f:
        f.write(data)


FAST = dict(log2_n=10)  # low scrypt cost so tests run quickly


class Base(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, self.d, True)

    def p(self, name):
        return os.path.join(self.d, name)

    def write(self, name, data):
        with open(self.p(name), "wb") as f:
            f.write(data)
        return self.p(name)

    def roundtrip(self, data, chunk=1024):
        src = self.write("in.bin", data)
        crypto.encrypt_file(src, self.p("e.svlt"), "pw", chunk_size=chunk, **FAST)
        crypto.decrypt_file(self.p("e.svlt"), self.p("out.bin"), "pw")
        with open(self.p("out.bin"), "rb") as f:
            return f.read()


class TestRoundTrip(Base):
    def test_empty_file(self):
        self.assertEqual(self.roundtrip(b""), b"")

    def test_small_file(self):
        self.assertEqual(self.roundtrip(b"hello world"), b"hello world")

    def test_exact_chunk_boundary(self):
        data = os.urandom(1024 * 3)
        self.assertEqual(self.roundtrip(data), data)

    def test_multi_chunk_with_remainder(self):
        data = os.urandom(1024 * 5 + 37)
        self.assertEqual(self.roundtrip(data), data)

    def test_unicode_password(self):
        src = self.write("a", b"secret")
        crypto.encrypt_file(src, self.p("a.svlt"), "pässwörd-密码", **FAST)
        crypto.decrypt_file(self.p("a.svlt"), self.p("a.out"), "pässwörd-密码")
        self.assertEqual(rd(self.p("a.out")), b"secret")


class TestSecurity(Base):
    def encrypted(self, size=4096):
        src = self.write("in", os.urandom(size))
        crypto.encrypt_file(src, self.p("e"), "pw", chunk_size=1024, **FAST)
        return self.p("e")

    def test_wrong_password(self):
        e = self.encrypted()
        with self.assertRaises(DecryptionError):
            crypto.decrypt_file(e, self.p("o"), "wrong")
        self.assertFalse(os.path.exists(self.p("o")))
        self.assertFalse(os.path.exists(self.p("o.part")))

    def test_flip_byte_in_ciphertext(self):
        e = self.encrypted()
        b = bytearray(rd(e))
        b[HEADER_LEN + 100] ^= 1
        wr(e, b)
        with self.assertRaises(DecryptionError):
            crypto.decrypt_file(e, self.p("o"), "pw")

    def test_flip_byte_in_header(self):
        e = self.encrypted()
        b = bytearray(rd(e))
        b[40] ^= 1  # nonce prefix region
        wr(e, b)
        with self.assertRaises(DecryptionError):
            crypto.decrypt_file(e, self.p("o"), "pw")

    def test_truncation_detected(self):
        e = self.encrypted()
        b = rd(e)
        enc_chunk = 1024 + 16
        wr(e, b[: HEADER_LEN + enc_chunk * 2])  # drop trailing chunks
        with self.assertRaises(DecryptionError):
            crypto.decrypt_file(e, self.p("o"), "pw")

    def test_chunk_reordering_detected(self):
        e = self.encrypted(size=1024 * 4)
        b = rd(e)
        c = 1024 + 16
        body = [b[HEADER_LEN + i * c: HEADER_LEN + (i + 1) * c] for i in range(4)]
        body[0], body[1] = body[1], body[0]
        wr(e, b[:HEADER_LEN] + b"".join(body) + b[HEADER_LEN + 4 * c:])
        with self.assertRaises(DecryptionError):
            crypto.decrypt_file(e, self.p("o"), "pw")

    def test_bad_magic(self):
        f = self.write("x", b"NOPE" + b"\x00" * 100)
        with self.assertRaises(FormatError):
            crypto.decrypt_file(f, self.p("o"), "pw")

    def test_short_file(self):
        f = self.write("x", b"SV")
        with self.assertRaises(FormatError):
            crypto.read_header(f)

    def test_salt_and_ciphertext_differ_each_time(self):
        src = self.write("in", b"same data")
        crypto.encrypt_file(src, self.p("a"), "pw", **FAST)
        crypto.encrypt_file(src, self.p("b"), "pw", **FAST)
        self.assertNotEqual(rd(self.p("a")), rd(self.p("b")))

    def test_plaintext_not_in_ciphertext(self):
        src = self.write("in", b"TOP-SECRET-MARKER" * 50)
        crypto.encrypt_file(src, self.p("a"), "pw", **FAST)
        self.assertNotIn(b"TOP-SECRET-MARKER", rd(self.p("a")))

    def test_empty_password_rejected(self):
        src = self.write("in", b"x")
        with self.assertRaises(ValueError):
            crypto.encrypt_file(src, self.p("a"), "", **FAST)

    def test_hostile_kdf_params_rejected(self):
        e = self.encrypted()
        b = bytearray(rd(e))
        b[6] = 40  # log2_n absurdly large (DoS attempt)
        wr(e, b)
        with self.assertRaises(FormatError):
            crypto.decrypt_file(e, self.p("o"), "pw")


class TestHelpers(Base):
    def test_secure_delete(self):
        f = self.write("s", b"data" * 1000)
        secure_delete(f)
        self.assertFalse(os.path.exists(f))

    def test_strength(self):
        self.assertEqual(estimate_strength("abc")[0], "Weak")
        self.assertIn(estimate_strength(generate_password(24))[0], ("Strong", "Very strong"))

    def test_generate_unique(self):
        self.assertNotEqual(generate_password(), generate_password())


class TestCLI(Base):
    def run_cli(self, *args, pw="pw"):
        env = dict(os.environ, SECUREVAULT_PASSWORD=pw)
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        return subprocess.run([sys.executable, "-m", "securevault", *args],
                              capture_output=True, text=True, env=env, cwd=root)

    def test_cli_roundtrip_and_info(self):
        src = self.write("doc.txt", b"cli test")
        self.assertEqual(self.run_cli("encrypt", src).returncode, 0)
        self.assertTrue(os.path.exists(src + ".svlt"))
        self.assertIn("AES-256-GCM", self.run_cli("info", src + ".svlt").stdout)
        os.remove(src)
        self.assertEqual(self.run_cli("decrypt", src + ".svlt").returncode, 0)
        self.assertEqual(rd(src), b"cli test")

    def test_cli_wrong_password(self):
        src = self.write("doc.txt", b"x")
        self.run_cli("encrypt", src)
        r = self.run_cli("decrypt", src + ".svlt", "-o", self.p("o"), pw="bad")
        self.assertNotEqual(r.returncode, 0)


if __name__ == "__main__":
    unittest.main()
