"""SecureVault - authenticated, streaming file encryption."""
from .crypto import encrypt_file, decrypt_file, read_header, DecryptionError, FormatError

__all__ = ["encrypt_file", "decrypt_file", "read_header", "DecryptionError", "FormatError"]
__version__ = "1.0.0"
