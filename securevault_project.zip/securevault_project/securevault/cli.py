"""Command-line interface: python -m securevault <command> ..."""
import argparse
import getpass
import os
import sys

from . import crypto
from .passwords import estimate_strength, generate_password
from .shred import secure_delete


def _bar(done, total):
    pct = 100 if total == 0 else int(done * 100 / total)
    sys.stderr.write(f"\r  progress: {pct:3d}%")
    if done >= total:
        sys.stderr.write("\n")
    sys.stderr.flush()


def _get_password(confirm: bool) -> str:
    env = os.environ.get("SECUREVAULT_PASSWORD")
    if env:
        return env
    pw = getpass.getpass("Password: ")
    if confirm:
        if pw != getpass.getpass("Confirm password: "):
            sys.exit("Error: passwords do not match.")
        label, bits = estimate_strength(pw)
        print(f"  Password strength: {label} (~{bits} bits)")
        if label == "Weak":
            print("  Warning: weak password. Consider `securevault genpass`.")
    return pw


def cmd_encrypt(a):
    out = a.output or a.file + ".svlt"
    if os.path.exists(out) and not a.force:
        sys.exit(f"Error: {out} exists (use --force to overwrite).")
    crypto.encrypt_file(a.file, out, _get_password(True), progress=_bar)
    print(f"Encrypted -> {out}")
    if a.shred:
        secure_delete(a.file)
        print(f"Original securely deleted: {a.file}")


def cmd_decrypt(a):
    out = a.output
    if not out:
        out = a.file[:-5] if a.file.endswith(".svlt") else a.file + ".dec"
    if os.path.exists(out) and not a.force:
        sys.exit(f"Error: {out} exists (use --force to overwrite).")
    try:
        crypto.decrypt_file(a.file, out, _get_password(False), progress=_bar)
    except (crypto.DecryptionError, crypto.FormatError) as e:
        sys.exit(f"Error: {e}")
    print(f"Decrypted -> {out}")


def cmd_info(a):
    try:
        h = crypto.read_header(a.file)
    except crypto.FormatError as e:
        sys.exit(f"Error: {e}")
    print(f"Format version : {h.version}")
    print("Cipher         : AES-256-GCM (chunked)")
    print(f"KDF            : scrypt N=2^{h.log2_n} r={h.r} p={h.p}")
    print(f"Chunk size     : {h.chunk_size} bytes")
    print(f"Salt           : {h.salt.hex()}")


def cmd_genpass(a):
    pw = generate_password(a.length)
    print(pw)
    label, bits = estimate_strength(pw)
    print(f"({label}, ~{bits} bits)", file=sys.stderr)


def main(argv=None):
    p = argparse.ArgumentParser(prog="securevault",
                                description="Authenticated file encryption (AES-256-GCM + scrypt).")
    sub = p.add_subparsers(dest="cmd", required=True)

    e = sub.add_parser("encrypt", help="encrypt a file")
    e.add_argument("file"); e.add_argument("-o", "--output")
    e.add_argument("--shred", action="store_true", help="securely delete original afterwards")
    e.add_argument("-f", "--force", action="store_true")
    e.set_defaults(fn=cmd_encrypt)

    d = sub.add_parser("decrypt", help="decrypt a file")
    d.add_argument("file"); d.add_argument("-o", "--output")
    d.add_argument("-f", "--force", action="store_true")
    d.set_defaults(fn=cmd_decrypt)

    i = sub.add_parser("info", help="show header information (no password needed)")
    i.add_argument("file"); i.set_defaults(fn=cmd_info)

    g = sub.add_parser("genpass", help="generate a strong random password")
    g.add_argument("-l", "--length", type=int, default=20); g.set_defaults(fn=cmd_genpass)

    a = p.parse_args(argv)
    a.fn(a)


if __name__ == "__main__":
    main()
