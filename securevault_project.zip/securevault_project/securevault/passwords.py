"""Password strength estimation and secure password generation."""
import math
import secrets
import string


def estimate_strength(password: str) -> tuple[str, float]:
    """Return (label, entropy_bits). A rough character-pool estimate."""
    pool = 0
    if any(c.islower() for c in password): pool += 26
    if any(c.isupper() for c in password): pool += 26
    if any(c.isdigit() for c in password): pool += 10
    if any(c in string.punctuation for c in password): pool += 32
    if any(c == " " for c in password): pool += 1
    bits = len(password) * math.log2(pool) if pool else 0.0
    common = {"password", "123456", "qwerty", "letmein", "admin", "welcome"}
    if password.lower() in common:
        bits = min(bits, 10)
    if bits < 40: label = "Weak"
    elif bits < 60: label = "Fair"
    elif bits < 80: label = "Strong"
    else: label = "Very strong"
    return label, round(bits, 1)


def generate_password(length: int = 20) -> str:
    alphabet = string.ascii_letters + string.digits + "!@#$%^&*()-_=+"
    return "".join(secrets.choice(alphabet) for _ in range(length))
