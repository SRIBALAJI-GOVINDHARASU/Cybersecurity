"""Best-effort secure deletion (overwrite then unlink).

LIMITATION: on SSDs (wear levelling), journaling or copy-on-write file
systems (ext4 journal, btrfs, APFS) and cloud-synced folders, overwriting
cannot guarantee the old data is gone. Full-disk encryption is the real
defence; this is documented as a known limitation.
"""
import os


def secure_delete(path: str, passes: int = 3, block: int = 1024 * 1024) -> None:
    size = os.path.getsize(path)
    with open(path, "r+b", buffering=0) as f:
        for _ in range(passes):
            f.seek(0)
            remaining = size
            while remaining > 0:
                n = min(block, remaining)
                f.write(os.urandom(n))
                remaining -= n
            f.flush()
            os.fsync(f.fileno())
    os.remove(path)
