"""Tkinter GUI: python -m securevault.gui"""
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from . import crypto
from .passwords import estimate_strength, generate_password


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("SecureVault - File Encryption")
        self.geometry("560x330")
        self.resizable(False, False)
        self.path = tk.StringVar()
        self.pw = tk.StringVar()
        self.pw2 = tk.StringVar()
        self.strength = tk.StringVar(value="Strength: -")
        self.status = tk.StringVar(value="Ready")
        pad = {"padx": 10, "pady": 5}

        ttk.Label(self, text="File").grid(row=0, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.path, width=44).grid(row=0, column=1, **pad)
        ttk.Button(self, text="Browse", command=self.browse).grid(row=0, column=2, **pad)

        ttk.Label(self, text="Password").grid(row=1, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.pw, show="*", width=44).grid(row=1, column=1, **pad)
        self.pw.trace_add("write", self.update_strength)
        ttk.Button(self, text="Generate", command=self.gen).grid(row=1, column=2, **pad)

        ttk.Label(self, text="Confirm").grid(row=2, column=0, sticky="w", **pad)
        ttk.Entry(self, textvariable=self.pw2, show="*", width=44).grid(row=2, column=1, **pad)
        ttk.Label(self, textvariable=self.strength).grid(row=3, column=1, sticky="w", **pad)

        bf = ttk.Frame(self)
        bf.grid(row=4, column=0, columnspan=3, pady=12)
        self.b_enc = ttk.Button(bf, text="Encrypt", command=lambda: self.run(True))
        self.b_dec = ttk.Button(bf, text="Decrypt", command=lambda: self.run(False))
        self.b_enc.pack(side="left", padx=10)
        self.b_dec.pack(side="left", padx=10)

        self.bar = ttk.Progressbar(self, length=500, maximum=100)
        self.bar.grid(row=5, column=0, columnspan=3, **pad)
        ttk.Label(self, textvariable=self.status).grid(row=6, column=0, columnspan=3, **pad)

    def browse(self):
        f = filedialog.askopenfilename()
        if f:
            self.path.set(f)

    def gen(self):
        p = generate_password(20)
        self.pw.set(p)
        self.pw2.set(p)
        self.clipboard_clear()
        self.clipboard_append(p)
        messagebox.showinfo("Generated", "Password generated and copied to clipboard.\n"
                            "Save it safely: it cannot be recovered.")

    def update_strength(self, *_):
        label, bits = estimate_strength(self.pw.get())
        self.strength.set(f"Strength: {label} (~{bits} bits)")

    def progress(self, done, total):
        self.after(0, lambda: self.bar.configure(value=100 if total == 0 else done * 100 / total))

    def run(self, encrypt):
        src = self.path.get()
        if not src:
            return messagebox.showwarning("No file", "Choose a file first.")
        if encrypt and self.pw.get() != self.pw2.get():
            return messagebox.showerror("Mismatch", "Passwords do not match.")
        if not self.pw.get():
            return messagebox.showwarning("Password", "Enter a password.")
        dst = src + ".svlt" if encrypt else (src[:-5] if src.endswith(".svlt") else src + ".dec")
        for b in (self.b_enc, self.b_dec):
            b.state(["disabled"])
        self.status.set("Working...")
        self.bar.configure(value=0)
        threading.Thread(target=self.worker, args=(encrypt, src, dst, self.pw.get()),
                         daemon=True).start()

    def worker(self, encrypt, src, dst, pw):
        try:
            fn = crypto.encrypt_file if encrypt else crypto.decrypt_file
            fn(src, dst, pw, progress=self.progress)
            self.after(0, lambda: self.done(f"Saved: {dst}", None))
        except (crypto.DecryptionError, crypto.FormatError) as e:
            self.after(0, lambda: self.done("Failed", str(e)))
        except Exception as e:
            self.after(0, lambda: self.done("Error", str(e)))

    def done(self, status, err):
        self.status.set(status)
        for b in (self.b_enc, self.b_dec):
            b.state(["!disabled"])
        if err:
            messagebox.showerror("SecureVault", err)


def main():
    App().mainloop()


if __name__ == "__main__":
    main()
