"""
Core cryptography for SecureVault.

File format (version 1)
-----------------------
Header (fixed 45 bytes, authenticated as AAD on every chunk):
    magic        4 bytes   b"SVLT"
    version      1 byte    0x01
    kdf_id       1 byte    0x01 = scrypt
    log2_n       1 byte    scrypt cost parameter N = 2**log2_n
    r            1 byte    scrypt block size
    p            1 byte    scrypt parallelism
    chunk_size   4 bytes   big-endian plaintext bytes per chunk
    salt         16 bytes  random per file
    nonce_prefix 8 bytes   random per file
    reserved     8 bytes   zero (future use)

Body: sequence of AES-256-GCM chunks, each (plaintext_len + 16 tag) bytes.
    nonce = nonce_prefix || chunk_index (4 bytes, big-endian)
    AAD   = header || final_flag (1 byte: 0x00 normal, 0x01 last chunk)

Security properties
-------------------
* Confidentiality + integrity of every chunk (AES-GCM).
* Header tampering is detected (header is AAD).
* Chunk reordering is detected (index is part of the nonce).
* Truncation is detected (the final chunk carries a "last" flag in AAD).
* Fresh salt and nonce prefix per file, so the same password never
  yields the same key or nonce twice.
"""
import os
import struct
from dataclasses import dataclass

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"SVLT"
VERSION = 1
KDF_SCRYPT = 1
TAG_LEN = 16
SALT_LEN = 16
NONCE_PREFIX_LEN = 8
HEADER_FMT = ">4sBBBBBI16s8s8s"
HEADER_LEN = struct.calcsize(HEADER_FMT)  # 45 bytes

DEFAULT_CHUNK = 1024 * 1024  # 1 MiB
DEFAULT_LOG2_N = 17          # N=131072 (~128 MiB RAM at r=8, ~0.3 s): OWASP-recommended
DEFAULT_R = 8
DEFAULT_P = 1
MAX_CHUNK = 64 * 1024 * 1024
MAX_LOG2_N = 22              # refuse absurd costs from hostile headers


class FormatError(Exception):
    """File is not a valid SecureVault file."""


class DecryptionError(Exception):
    """Wrong password, or the file was modified/corrupted."""


@dataclass
class Header:
    version: int
    kdf_id: int
    log2_n: int
    r: int
    p: int
    chunk_size: int
    salt: bytes
    nonce_prefix: bytes
    raw: bytes


def _derive_key(password: str, salt: bytes, log2_n: int, r: int, p: int) -> bytes:
    kdf = Scrypt(salt=salt, length=32, n=2 ** log2_n, r=r, p=p)
    return kdf.derive(password.encode("utf-8"))


def _parse_header(raw: bytes) -> Header:
    if len(raw) < HEADER_LEN:
        raise FormatError("File too short to be a SecureVault file.")
    magic, ver, kdf, log2_n, r, p, chunk, salt, prefix, _res = struct.unpack(
        HEADER_FMT, raw[:HEADER_LEN]
    )
    if magic != MAGIC:
        raise FormatError("Not a SecureVault file (bad magic bytes).")
    if ver != VERSION:
        raise FormatError(f"Unsupported format version {ver}.")
    if kdf != KDF_SCRYPT:
        raise FormatError(f"Unsupported KDF id {kdf}.")
    if not (10 <= log2_n <= MAX_LOG2_N) or not (1 <= r <= 32) or not (1 <= p <= 16):
        raise FormatError("Unreasonable KDF parameters in header.")
    if not (1 <= chunk <= MAX_CHUNK):
        raise FormatError("Unreasonable chunk size in header.")
    return Header(ver, kdf, log2_n, r, p, chunk, salt, prefix, raw[:HEADER_LEN])


def read_header(path: str) -> Header:
    with open(path, "rb") as f:
        return _parse_header(f.read(HEADER_LEN))


def _nonce(prefix: bytes, index: int) -> bytes:
    return prefix + struct.pack(">I", index)


def encrypt_file(src, dst, password, chunk_size=DEFAULT_CHUNK,
                 log2_n=DEFAULT_LOG2_N, r=DEFAULT_R, p=DEFAULT_P, progress=None):
    """Encrypt src -> dst. progress(done_bytes, total_bytes) is optional."""
    if not password:
        raise ValueError("Password must not be empty.")
    salt = os.urandom(SALT_LEN)
    prefix = os.urandom(NONCE_PREFIX_LEN)
    header = struct.pack(HEADER_FMT, MAGIC, VERSION, KDF_SCRYPT, log2_n, r, p,
                         chunk_size, salt, prefix, b"\x00" * 8)
    key = _derive_key(password, salt, log2_n, r, p)
    aead = AESGCM(key)
    total = os.path.getsize(src)
    done = 0
    index = 0
    tmp = dst + ".part"
    try:
        with open(src, "rb") as fin, open(tmp, "wb") as fout:
            fout.write(header)
            chunk = fin.read(chunk_size)
            while True:
                nxt = fin.read(chunk_size)  # one-chunk lookahead to detect the last one
                last = not nxt
                if index >= 2 ** 32 - 1:
                    raise OverflowError("File too large for this chunk size.")
                aad = header + (b"\x01" if last else b"\x00")
                fout.write(aead.encrypt(_nonce(prefix, index), chunk, aad))
                done += len(chunk)
                index += 1
                if progress:
                    progress(done, total)
                if last:
                    break
                chunk = nxt
            fout.flush()
            os.fsync(fout.fileno())
        os.replace(tmp, dst)
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)
        raise
    finally:
        del key


def decrypt_file(src, dst, password, progress=None):
    """Decrypt src -> dst. Output is only created if the whole file verifies."""
    with open(src, "rb") as fin:
        h = _parse_header(fin.read(HEADER_LEN))
    key = _derive_key(password, h.salt, h.log2_n, h.r, h.p)
    aead = AESGCM(key)
    enc_chunk = h.chunk_size + TAG_LEN
    total = os.path.getsize(src) - HEADER_LEN
    done = 0
    index = 0
    tmp = dst + ".part"
    try:
        with open(src, "rb") as fin, open(tmp, "wb") as fout:
            fin.seek(HEADER_LEN)
            chunk = fin.read(enc_chunk)
            if len(chunk) < TAG_LEN:
                raise DecryptionError("File is truncated or corrupted.")
            while True:
                nxt = fin.read(enc_chunk)
                last = not nxt
                aad = h.raw + (b"\x01" if last else b"\x00")
                try:
                    pt = aead.decrypt(_nonce(h.nonce_prefix, index), chunk, aad)
                except InvalidTag:
                    raise DecryptionError(
                        "Decryption failed: wrong password, or the file was "
                        "tampered with, truncated, or corrupted."
                    ) from None
                fout.write(pt)
                done += len(chunk)
                index += 1
                if progress:
                    progress(done, total)
                if last:
                    break
                chunk = nxt
            fout.flush()
            os.fsync(fout.fileno())
        os.replace(tmp, dst)
    except BaseException:
        if os.path.exists(tmp):
            os.remove(tmp)  # never leave unverified plaintext behind
        raise
    finally:
        del key
