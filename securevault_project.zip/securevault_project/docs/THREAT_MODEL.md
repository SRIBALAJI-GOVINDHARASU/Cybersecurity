# Threat Model

## Assets
File contents and their integrity.

## Adversaries and scope
| Adversary | In scope? | Outcome |
|---|---|---|
| Thief with a stolen laptop/USB/backup holding `.svlt` files | Yes | Must brute-force the password against scrypt |
| Network eavesdropper on a file transfer | Yes | Sees only ciphertext |
| Attacker who modifies the file in transit/storage | Yes | Detected; decryption refuses |
| Attacker supplying a malicious `.svlt` file | Yes | Header validated; no crash/DoS |
| Cloud provider reading stored files | Yes | Ciphertext only |
| Malware or keylogger on the running system | No | Can capture password/plaintext |
| Coercion / rubber-hose attacks | No | |
| Side channels (cache/timing/power) | Mostly no | Relies on library implementation |
| Metadata analysis (name, size, timestamps) | No | Not hidden |

## Assumptions
OS CSPRNG is sound; `cryptography`/OpenSSL are correctly implemented; user
chooses a reasonably strong password.

## Security properties
Confidentiality, integrity, authenticity-by-password, freshness-not-provided
(an attacker can replace a file with an older valid version; anti-rollback
requires external state).
