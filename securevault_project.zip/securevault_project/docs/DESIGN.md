# Design Document

## 1. Goals
Protect files at rest with strong, correctly-composed cryptography; detect any
modification; fail safely; handle files larger than RAM.

## 2. Algorithm choices and justification
| Decision | Choice | Why |
|---|---|---|
| Cipher | AES-256-GCM | NIST-approved AEAD; hardware accelerated (AES-NI); provides integrity |
| Rejected | AES-ECB | Leaks patterns (the "ECB penguin") |
| Rejected | AES-CBC alone | No integrity; padding-oracle attacks; needs separate MAC |
| KDF | scrypt | Memory-hard, resists GPU/ASIC brute force; unlike a plain hash or low-iteration PBKDF2 |
| Randomness | `os.urandom` / `secrets` | OS CSPRNG, not `random` |
| Library | `cryptography` | Audited; avoids rolling own crypto |

(Argon2id is the current OWASP first choice; scrypt was chosen because it ships
in the `cryptography` package with no extra dependency. The header has a
`kdf_id` field so Argon2id can be added in format v2 without breaking old files.)

## 3. Encryption flow
1. Generate random 16-byte salt and 8-byte nonce prefix.
2. `key = scrypt(password, salt, N, r, p)` -> 32 bytes.
3. Build 45-byte header (magic, version, KDF params, chunk size, salt, prefix).
4. Read the file in 1 MiB chunks with one-chunk lookahead (to know which is last).
5. For chunk *i*: `nonce = prefix || i`, `AAD = header || last_flag`;
   `AES-GCM-Encrypt(key, nonce, chunk, AAD)` -> ciphertext + 16-byte tag.
6. Write to `<out>.part`, `fsync`, atomically rename.

## 4. File format
```
offset size  field
0      4     magic "SVLT"
4      1     version (1)
5      1     kdf id (1 = scrypt)
6      1     log2(N)
7      1     r
8      1     p
9      4     chunk size (big-endian)
13     16    salt
29     8     nonce prefix
37     8     reserved
45     ...   chunks: [ciphertext || 16-byte tag] ...
```

## 5. Attacks considered and how they are handled
| Attack | Mitigation |
|---|---|
| Brute-force password | scrypt cost; strength meter; generator |
| Rainbow tables | Unique random salt per file |
| Bit-flipping / modification | GCM tag per chunk |
| Header tampering (e.g. downgrade KDF cost) | Header included as AAD |
| Chunk reordering / swapping | Chunk index inside nonce |
| Truncation (drop trailing chunks) | "last chunk" flag in AAD |
| Nonce reuse | Random prefix per file + counter per chunk |
| Resource exhaustion via crafted header | Parameter range checks |
| Plaintext leak on failed decrypt | Temp file deleted; output only after success |
| Partial/corrupt output on crash | Atomic rename |

## 6. Limitations (be honest in your report)
- Password-only security: a weak password is the weakest link.
- No protection against malware/keyloggers on a running machine.
- Python cannot reliably zero memory; keys may linger until GC.
- Secure delete is unreliable on SSDs, journaling/CoW filesystems, cloud sync.
- File names, sizes and modification times are not hidden.
- No key recovery: a forgotten password means permanently lost data (by design).

## 7. Future work
Argon2id; hybrid public-key mode (X25519 + HKDF) for sharing; directory
encryption; key files / hardware tokens (YubiKey); multi-password key slots;
memory locking (`mlock`); parallel chunk processing.

## 8. Measured results (sample machine; rerun `python benchmark.py` on yours)
scrypt key-derivation time (r=8, p=1): 2^12 = 0.011 s, 2^14 = 0.040 s,
2^15 = 0.081 s, 2^16 = 0.166 s, 2^17 = 0.337 s, 2^18 = 0.737 s.
Each doubling of N doubles the attacker's cost per guess. Default is 2^17.
Throughput with 1 MiB chunks: roughly 750 MiB/s encrypt and decrypt (AES-NI).
Memory: ~55 MB peak for a 200 MB file (constant, independent of file size).
