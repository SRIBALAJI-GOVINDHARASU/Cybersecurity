# Suggested Final Year Report Structure

1. **Abstract**
2. **Introduction**: problem (data theft/breaches), objectives, scope
3. **Literature review**: symmetric vs asymmetric crypto, block cipher modes
   (ECB/CBC/CTR/GCM), AEAD, KDFs (PBKDF2/bcrypt/scrypt/Argon2), existing tools
   (VeraCrypt, GPG, age, 7-Zip AES), NIST SP 800-38D, SP 800-132, RFC 7914
4. **Requirements analysis**: functional + non-functional
5. **System design**: architecture diagram, flowcharts, file format (see DESIGN.md)
6. **Threat model** (see THREAT_MODEL.md)
7. **Implementation**: modules, key code listings, challenges
8. **Testing**: unit tests, tamper tests, large-file test, performance table
9. **Results and evaluation**: throughput, memory, scrypt time vs N
10. **Limitations and future work**
11. **Conclusion**; **References**; **Appendix** (source, user manual)

## Experiments worth including (easy marks)
- Time to derive a key for log2_n = 12..18 (shows brute-force cost trade-off).
- Throughput vs chunk size (64 KiB to 16 MiB).
- Demonstrate AES-ECB pattern leakage vs GCM on an image.
- Flip one byte and show the tamper alarm.
- Compare with a naive design (password hashed with SHA-256 as key) and show why it is weak.

## Likely viva questions
1. Why GCM over CBC? (integrity built in; CBC needs a MAC and has padding oracles)
2. Why can't you reuse a nonce with GCM? (leaks XOR of plaintexts and the auth key)
3. Why scrypt and not SHA-256(password)? (fast hash = fast brute force)
4. What is a salt for? (defeats precomputation, makes identical passwords differ)
5. How do you stop truncation/reordering of chunks? (AAD last flag; index in nonce)
6. Why is the header authenticated if it is not secret? (prevents tampering/downgrade)
7. What happens on a wrong password? (tag mismatch; no output written)
8. What does your tool NOT protect against? (malware, weak passwords, metadata)
9. Why is secure delete unreliable on SSDs? (wear levelling remaps blocks)
10. How would you add file sharing? (hybrid: random file key wrapped with recipient's public key)
