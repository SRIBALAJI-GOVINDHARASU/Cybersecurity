# SecureVault: Authenticated File Encryption Tool

A final year cybersecurity project implementing secure file encryption and
decryption with **AES-256-GCM**, **scrypt** password-based key derivation, and a
custom versioned, tamper-evident file format. Includes a CLI, a Tkinter GUI,
secure deletion, a password strength meter/generator, and a 21-test suite.

## Features
| Feature | Detail |
|---|---|
| Cipher | AES-256-GCM (AEAD: confidentiality + integrity) |
| Key derivation | scrypt (N=2^17, r=8, p=1), random 16-byte salt per file |
| Streaming | 1 MiB chunks; constant memory (~55 MB for a 200 MB file) |
| Tamper detection | Header authenticated; reorder and truncation attacks detected |
| Safe failure | Output written to `.part`, renamed only after full verification |
| Hostile input | KDF/chunk parameters in headers are range-checked (DoS defence) |
| Extras | Secure delete, password generator, strength meter, `info` command |

## Install and run
```bash
pip install -r requirements.txt        # Python 3.9+ ; GUI needs tkinter
python -m securevault encrypt report.pdf          # -> report.pdf.svlt
python -m securevault decrypt report.pdf.svlt     # -> report.pdf
python -m securevault encrypt secret.txt --shred  # securely delete original
python -m securevault info report.pdf.svlt        # header details, no password
python -m securevault genpass -l 24               # strong random password
python -m securevault.gui                         # graphical interface
```
Linux note: if the GUI fails, install tkinter (`sudo apt install python3-tk`).

Set `SECUREVAULT_PASSWORD` to avoid the prompt (for scripting only; environment
variables can leak, so prefer the interactive prompt).

## Run the tests
```bash
./run_tests.sh        # or: python -m unittest discover -s tests -v
```

## Project structure
```
securevault/
  crypto.py      core: file format, KDF, chunked AES-GCM
  cli.py         command-line interface
  gui.py         Tkinter GUI
  passwords.py   strength estimator + secure generator
  shred.py       best-effort secure deletion
tests/test_crypto.py    21 tests (round-trip, tampering, truncation, CLI...)
docs/DESIGN.md          design decisions, file format, algorithms
docs/THREAT_MODEL.md    what is and is not protected
docs/REPORT_OUTLINE.md  suggested report chapters + viva questions
```

## Documentation
See `docs/` for the design rationale, threat model, report outline and likely
viva questions.

## License
Educational use. Built on the `cryptography` library; no custom primitives.
