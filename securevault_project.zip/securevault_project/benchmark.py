"""Produces data for the report: scrypt cost and throughput."""
import os, time, tempfile
from securevault import crypto

print("scrypt cost (key derivation time):")
for n in range(12, 19):
    t = time.perf_counter()
    crypto._derive_key("benchmark-password", os.urandom(16), n, 8, 1)
    print(f"  N=2^{n:<2} {time.perf_counter()-t:7.3f} s")

d = tempfile.mkdtemp()
src = os.path.join(d, "data.bin")
with open(src, "wb") as f:
    f.write(os.urandom(100 * 1024 * 1024))
print("\nthroughput on 100 MiB (chunk size sweep):")
for kib in (64, 256, 1024, 4096, 16384):
    out = src + ".svlt"
    t = time.perf_counter()
    crypto.encrypt_file(src, out, "pw", chunk_size=kib * 1024, log2_n=10)
    enc = time.perf_counter() - t
    t = time.perf_counter()
    crypto.decrypt_file(out, src + ".dec", "pw")
    dec = time.perf_counter() - t
    print(f"  chunk {kib:>6} KiB  enc {100/enc:7.1f} MiB/s   dec {100/dec:7.1f} MiB/s")
    os.remove(out); os.remove(src + ".dec")
os.remove(src)
